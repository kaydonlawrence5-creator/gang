groupsConfig = {
    ["Barragem"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Barragem",
            ["Permission"] = "Barragem",
        },
    },
    ["Policia"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Policia",
            ["Permission"] = "Policia",
        },
    },
    ["Bombeiros"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Bombeiros",
            ["Permission"] = "Bombeiros",
        },
    },
    ["Juridico"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Juridico",
            ["Permission"] = "Juridico",
        },
    },
    ["Cartel"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Cartel",
            ["Permission"] = "Cartel",
        },
    },
    ["Paramedic"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Paramedic",
            ["Permission"] = "Paramedic",
        },
    },
    ["Mechanic"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Mechanic",
            ["Permission"] = "Mechanic",
        },
    },
    ["Sindicato"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Sindicato",
            ["Permission"] = "Sindicato",
        },
    },
    ["Vagos"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Vagos",
            ["Permission"] = "Vagos",
        },
    },
    ["Umbrella"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Umbrella",
            ["Permission"] = "Umbrella",
        },
    },
    ["Azuis"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Azuis",
            ["Permission"] = "Azuis",
        },
    },
    ["Vermelhos"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Vermelhos",
            ["Permission"] = "Vermelhos",
        },
    },
    ["Amarelos"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Amarelos",
            ["Permission"] = "Amarelos",
        },
    },
    ["AlcateiaHsT"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "AlcateiaHsT",
            ["Permission"] = "AlcateiaHsT",
        },
    },
    ["Verdes"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Verdes",
            ["Permission"] = "Verdes",
        },
    },
    ["Roxos"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Roxos",
            ["Permission"] = "Roxos",
        },
    },
    ["LosAztecas"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "LosAztecas",
            ["Permission"] = "LosAztecas",
        },
    },
    ["Laranjas"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Laranjas",
            ["Permission"] = "Laranjas",
        },
    },
    ["Brancos"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Brancos",
            ["Permission"] = "Brancos",
        },
    },
    ["Marrons"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Marrons",
            ["Permission"] = "Marrons",
        },
    },
    ["Cinzas"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Cinzas",
            ["Permission"] = "Cinzas",
        },
    },
    ["Rosas"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Rosas",
            ["Permission"] = "Rosas",
        },
    },
    ["Ballas"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Ballas",
            ["Permission"] = "Ballas",
        },
    },
    ["Bellagio"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Bellagio",
            ["Permission"] = "Bellagio",
        },
    },


    ["Bahamas"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Bahamas",
            ["Permission"] = "Bahamas",
        },
    },
    ["Palazzo"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Palazzo",
            ["Permission"] = "Palazzo",
        },
    },
    ["Luxor"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Luxor",
            ["Permission"] = "Luxor",
        },
    },
    ["Groove"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Groove",
            ["Permission"] = "Groove",
        },
    },
    ["TopGear"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "TopGear",
            ["Permission"] = "TopGear",
        },
    },
    ["Redline"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Redline",
            ["Permission"] = "Redline",
        },
    },
    ["Bennys"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Bennys",
            ["Permission"] = "Bennys",
        },
    },
    ["DriftKing"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "DriftKing",
            ["Permission"] = "DriftKing",
        },
    },
    ["Forza"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Forza",
            ["Permission"] = "Forza",
        },
    },
    ["Overdrive"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Overdrive",
            ["Permission"] = "Overdrive",
        },
    },
    ["Crips"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Crips",
            ["Permission"] = "Crips",
        },
    },
    ["Tropadu7"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Tropadu7",
            ["Permission"] = "Tropadu7",
        },
    },
    ["Outlaws"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Outlaws",
            ["Permission"] = "Outlaws",
        },
    },
    ["SonsofAnarchy"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "SonsofAnarchy",
            ["Permission"] = "SonsofAnarchy",
        },
    },
    ["Sinaloa"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Sinaloa",
            ["Permission"] = "Sinaloa",
        },
    },
    ["HellsAngels"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "HellsAngels",
            ["Permission"] = "HellsAngels",
        },
    },
    ["Triade"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Triade",
            ["Permission"] = "Triade",
        },
    },
    ["Yakuza"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Yakuza",
            ["Permission"] = "Yakuza",
        },
    },
    ["Warlocks"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Warlocks",
            ["Permission"] = "Warlocks",
        },
    },
    ["Bloods"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Bloods",
            ["Permission"] = "Bloods",
        },
    },
    ["Mercenarios"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Mercenarios",
            ["Permission"] = "Mercenarios",
        },
    },
    ["Bopegg"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Bopegg",
            ["Permission"] = "Bopegg",
        },
    },
    ["LaMafia"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "LaMafia",
            ["Permission"] = "LaMafia",
        },
    },
    ["Gringa"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Gringa",
            ["Permission"] = "Gringa",
        },
    },
    ["Franca"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Franca",
            ["Permission"] = "Franca",
        },
    },
    ["Italia"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Italia",
            ["Permission"] = "Italia",
        },
    },
    ["Russia"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Russia",
            ["Permission"] = "Russia",
        },
    },
    ["Israel"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Israel",
            ["Permission"] = "Israel",
        },
    },
    ["Playboy"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Playboy",
            ["Permission"] = "Playboy",
        },
    },
    ["Mexico"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "Mexico",
            ["Permission"] = "Mexico",
        },
    },
    ["China"] = {
        ["Config"] = {
            ["Photo"] = "SEU LINK AQUI",
            ["Name"] = "China",
            ["Permission"] = "China",
        },
    }

}
-- CLASS == Item/Function
storeConfig = {
    ["Barragem"] = {
            -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
        {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },
        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },

    ["Policia"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Bombeiros"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Juridico"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Paramedic"] = {
                -- {
            -- 	name = "VIP Bronze",
            -- 	itemName = "premium05",
            -- 	index = "vip-bronze",
            -- 	type = "organization",
            -- 	classType = "item",
            -- 	price = 8500
            -- },
            -- {
            -- 	name = "Vip Prata",
            -- 	itemName = "premium04",
            -- 	index = "vip-prata",
            -- 	type = "organization",
            -- 	classType = "item",
            -- 	price = 11360
            -- },
            -- {
            -- 	name = "Vip Ouro",
            -- 	itemName = "premium03",
            -- 	index = "vip-ouro",
            -- 	type = "organization",
            -- 	classType = "item",
            -- 	price = 17050
            -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Mechanic"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Cartel"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Sindicato"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Vagos"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                        {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Umbrella"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Azuis"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Vermelhos"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Amarelos"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["AlcateiaHsT"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Verdes"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Roxos"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["LosAztecas"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Laranjas"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Brancos"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Marrons"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Cinzas"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Rosas"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Ballas"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Bellagio"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },

    ["Bahamas"] = {
                        -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Palazzo"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Luxor"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Groove"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["TopGear"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Redline"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Bennys"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["DriftKing"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Forza"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Overdrive"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Crips"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Tropadu7"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Outlaws"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["SonsofAnarchy"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Sinaloa"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["HellsAngels"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Triade"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Yakuza"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Warlocks"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Bloods"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Mercenarios"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Bopegg"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["LaMafia"] = {
                -- {
        -- 	name = "VIP Bronze",
        -- 	itemName = "premium05",
        -- 	index = "vip-bronze",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 8500
        -- },
        -- {
        -- 	name = "Vip Prata",
        -- 	itemName = "premium04",
        -- 	index = "vip-prata",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 11360
        -- },
        -- {
        -- 	name = "Vip Ouro",
        -- 	itemName = "premium03",
        -- 	index = "vip-ouro",
        -- 	type = "organization",
        -- 	classType = "item",
        -- 	price = 17050
        -- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Gringa"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Franca"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Italia"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Russia"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Israel"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Playboy"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["Mexico"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    },
    ["China"] = {
                -- {
-- 	name = "VIP Bronze",
-- 	itemName = "premium05",
-- 	index = "vip-bronze",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 8500
-- },
-- {
-- 	name = "Vip Prata",
-- 	itemName = "premium04",
-- 	index = "vip-prata",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 11360
-- },
-- {
-- 	name = "Vip Ouro",
-- 	itemName = "premium03",
-- 	index = "vip-ouro",
-- 	type = "organization",
-- 	classType = "item",
-- 	price = 17050
-- },
                {
            name = "Kit Fogueteiro",
            itemName = "kitfogueteiro",
            index = "kitfogueteiro",
            type = "organization",
            classType = "item",
            -- description = "Contém: 200 G36C, 200 Sig Sauer, 400 Five Seven, 75k de munições de pistola, 75k munição de rifle, 600 coca e 600 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>50</td> <td>G36C</td> <tr>  <td>50</td> <td>Sig Sauer</td> <tr> <td>100</td> <td>Five Seven</td> <tr> <td>15k</td> <td>munições de pistola</td> <tr> <td>15k</td> <td>munição de rifle</td> </table>",
            price = 2650
        },
        {
            name = "Kit Boqueta",
            itemName = "kitboqueta",
            index = "kitboqueta",
            type = "organization",
            classType = "item",
            -- description = "Contém: 100k de munições de pistola, 100k de munições de rifle, 1k de coca e 1k de Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3000
        },
        {
            name = "Kit Criminal",
            itemName = "kitcriminal",
            index = "kitcriminal",
            type = "organization",
            classType = "item",
            -- description = "Contém: 315 G36C, 315 Sig Sauer, 630 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>75</td> <td>G36C</td> <tr>  <td>75</td> <td>Sig Sauer</td> <tr> <td>150</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 3375
        },
        {
            name = "Kit Mafioso",
            itemName = "kitmafioso",
            index = "kitmafioso",
            type = "organization",
            classType = "item",
            -- description = "Contém: 550 G36C, 550 Sig Sauer, 1100 Five Seven, 115k de munições de pistola, 115k munição de rifle, 900 coca e 900 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>125</td> <td>G36C</td> <tr>  <td>125</td> <td>Sig Sauer</td> <tr> <td>250</td> <td>Five Seven</td> <tr> <td>25k</td> <td>munições de pistola</td> <tr> <td>25k</td> <td>munição de rifle</td> </table>",
            price = 4500
        },
        {
            name = "Kit dos Raul",
            itemName = "kitdosraul",
            index = "kitdosraul",
            type = "organization",
            classType = "item",
            -- description = "Contém: 750 G36C, 750 Sig Sauer, 1500 Five Seven, 130k de munições de pistola, 130k munição de rifle, 1050 coca e 1050 Baseado",
            description = "<table> <tr> <th>Contém</th> <tr>   <td>175</td> <td>G36C</td> <tr>  <td>175</td> <td>Sig Sauer</td> <tr> <td>375</td> <td>Five Seven</td> <tr> <td>30k</td> <td>munições de pistola</td> <tr> <td>30k</td> <td>munição de rifle</td> </table>",
            price = 6625
        },

        {
            name = "Vip Bronze",
            itemName = "premium05",
            index = "premium05",
            type = "organization",
            classType = "item",
            -- description = "Contém: 5kk, 5 G36C, 5 Five Seven, 10 coletes, 500 munições de rifle, 500 munições de pistola e escolha de 1 carro",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>5kk</td> <td>Dollars</td>  <tr> <td>5</td> <td>G36C</td> <tr> <td>5</td> <td>Five Seven</td> <tr> <td>10</td> <td>Coletes</td> <tr> <td>500</td> <td>munição de rifle</td> <tr> <td>500</td> <td>munições de pistola</td>  <tr> <td>1</td> <td>Escolha de carro</td> </table>",
            price = 6500
        },
        {
            name = "Vip Prata",
            itemName = "premium04",
            index = "premium04",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 20 G36C, 20 Five Seven, 50 coletes, 2k munições de rifle, 2k munições de pistola e escolha de 2 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>20</td> <td>G36C</td> <tr> <td>20</td> <td>Five Seven</td> <tr> <td>50</td> <td>Coletes</td> <tr> <td>2k</td> <td>munição de rifle</td> <tr> <td>2k</td> <td>munições de pistola</td>  <tr> <td>2</td> <td>Escolha de carro</td> </table>",
            price = 9000
        },
        {
            name = "Vip Ouro",
            itemName = "premium03",
            index = "premium03",
            type = "organization",
            classType = "item",
            -- description = "Contém: 10kk, 50 G36C, 50 Five Seven, 100 coletes, 5k munições de rifle, 5k munições de pistola e escolha de 3 carros",
            description = "<table> <tr> <th>Contém</th> <tr>    <td>10kk</td> <td>Dollars</td>  <tr> <td>50</td> <td>G36C</td> <tr> <td>50</td> <td>Five Seven</td> <tr> <td>100</td> <td>Coletes</td> <tr> <td>5k</td> <td>munição de rifle</td> <tr> <td>5k</td> <td>munições de pistola</td>  <tr> <td>3</td> <td>Escolha de carro</td> </table>",
            price = 11500
        },
        {
            name = "Sig Sauer 556",
            itemName = "WEAPON_SPECIALCARBINE_MK2",
            index = "sigsauer556",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "G36C",
            itemName = "WEAPON_SPECIALCARBINE",
            index = "g36c",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "Five Seven",
            itemName = "WEAPON_PISTOL_MK2",
            index = "fiveseven",
            type = "organization",
            classType = "item",
            price = 750
        },
        {
            name = "M. Rifle",
            itemName = "WEAPON_RIFLE_AMMO",
            index = "rifleammo",
            type = "organization",
            classType = "item",
            price = 15
        },

        {
            name = "M. Pistola",
            itemName = "WEAPON_PISTOL_AMMO",
            index = "pistolammo",
            type = "organization",
            classType = "item",
            price = 15
        },
        {
            name = "M. Sub",
            itemName = "WEAPON_SMG_AMMO",
            index = "smgammo",
            type = "organization",
            classType = "item",
            price = 15
        }
        -- {
        --     name = "Five",
        --     itemName = "WEAPON_PISTOL_MK2",
        --     index = "fiveseven",
        --     type = "organization",
        --     classType = "item",
        --     price = 1750
        -- },
        -- {
        --     name = "Uzi",
        --     itemName = "WEAPON_MICROSMG",
        --     index = "uzi",
        --     type = "organization",
        --     classType = "item",
        --     price = 1800
        -- },
        -- {
        --     name = "G3",
        --     itemName = "WEAPON_SPECIALCARBINE",
        --     index = "g36c",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "AK-47",
        --     itemName = "WEAPON_ASSAULTRIFLE_MK2",
        --     index = "ak74",
        --     type = "organization",
        --     classType = "item",
        --     price = 2600
        -- },
        -- {
        --     name = "Muni Pistola",
        --     itemName = "WEAPON_PISTOL_AMMO",
        --     index = "pistolammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Munição de Sub",
        --     itemName = "WEAPON_SMG_AMMO",
        --     index = "smgammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Muni Fuzil",
        --     itemName = "WEAPON_RIFLE_AMMO",
        --     index = "rifleammo",
        --     type = "organization",
        --     classType = "item",
        --     price = 20
        -- },
        -- {
        --     name = "Pack de Armas - Basic",
        --     itemName = "packbasic",
        --     index = "packbasic",
        --     type = "organization",
        --     classType = "item",
        --     price = 1705
        -- },
        -- {
        --     name = "Pack de Armas - Elite",
        --     itemName = "packelite",
        --     index = "packelite",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "Pack de Armas - Premium",
        --     itemName = "packpremium",
        --     index = "packpremium",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- },
        -- {
        --     name = "1 milhão de Dollars",
        --     itemName = "money4",
        --     index = "money4",
        --     type = "organization",
        --     classType = "item",
        --     price = 24000
        -- },
        -- {
        --     name = "10 milhões de Dollars",
        --     itemName = "money5",
        --     index = "money5",
        --     type = "organization",
        --     classType = "item",
        --     price = 34000
        -- }
    }
}

bankConfig = {
    ["deposit"] = "Deposito",
    ["withdraw"] = "Saque",
    ["remove"] = "Remover",
}

bankType = {
    [1] = "withdraw",
    [2] = "deposit",
    [3] = "remove",
}

ActionsConfig = {
    ["promote"] = true,
    ["demote"] =  true,
    ["fire"] = true
}

News = {
    ["Base"] = {
        -- {
        --     title = "",
        --     content = "",
        --     image = ",
        --     redirect? = "",
        --     createAt = 00000000000,
        -- }
    }
}

Discord = {
    ["Base"] = {
        -- ["Barragem"] = "SEU LINK AQUI",
    }
}